#include<stdio.h>

int main(){
    
    int n;
  
    printf("Enter the value of n: ");
    scanf("%d",&n);
   

   int matrix [n][n];
 printf("Enter value on the array\n");
    for(int i=0 ; i<n;i++){
        for(int j=0;j<n;j++){
            scanf("%d" , &matrix[i][j]);
        }
    }

    printf("Array value\n");
    for(int i=0 ; i<n;i++){
        for(int j=0;j<n;j++){
           printf("%d ",matrix[i][j]);
        }
        printf("\n");
    }

    // Major diagonal
printf("Major diagonal:");
    for(int i=0 ; i<n;i++){
        for(int j=0;j<n;j++){
         if(i==j){
            printf("%d ",matrix[i][j]);
            printf(" Index[%d][%d] " , i , j);
         }
        }   
    }
// Minor diagonal


    printf("\nMainor diagonal :");
    for(int i=0 ; i<n;i++){
        for(int j=0;j<n;j++){
         if(i+j == n-1){
            printf("%d ",matrix[i][j]);
            printf(" Index[%d][%d] " , i , j);
         }
        }   
    }



    



   


   


}