#include <stdio.h>

int main() {
    int n;
    
    printf("Enter the size of the square matrix (n): ");
    scanf("%d", &n);
    
    int matrix[n][n];
    
   
    printf("Enter the elements of the matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("Element at [%d][%d]: ", i, j);
            scanf("%d", &matrix[i][j]);
        }
    }
    
   
    printf("\nThe matrix is:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
    
   
    printf("\nPrimary diagonal elements: ");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if(i == j){
                printf("%d " , matrix[i][j]);
            }
        }
        
    }
    
    printf("\nSecondary diagonal elements: ");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if(i + j == n-1){
                printf("%d " , matrix[i][j]);
            }
        }
        
    }

    return 0;
}
