#include<stdio.h>

int main(){
    
   

    int A[3][3];
    int B[3][3];
    int C[3][3] = {{0}};
 printf("Enter value on the array A\n");
    for(int i=0 ; i<3;i++){
        for(int j=0;j<3;j++){
            scanf("%d" , &A[i][j]);
        }
    }

    printf("Enter value on the array B\n");
    for(int i=0 ; i<3;i++){
        for(int j=0;j<3;j++){
            scanf("%d" , &B[i][j]);
        }
    }

    for(int i=0 ; i<3;i++){
        for(int j=0;j<3;j++){
            for(int k=0 ; k<3;k++){
                C[i][j] += A[i][k] * B[k][j];
            }
        
        }
    }





    printf("Array value of C\n");
    for(int i=0 ; i<3;i++){
        for(int j=0;j<3;j++){
           printf("%d ",C[i][j]);
        }
        printf("\n");
    }
 




   


   


}