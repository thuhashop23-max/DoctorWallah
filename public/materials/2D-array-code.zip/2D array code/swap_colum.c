#include<stdio.h>

int main(){
    
    int row , col;
   
    printf("Enter the value of row: ");
    scanf("%d",&row);
    printf("Enter the value of column: ");
    scanf("%d",&col);

    int arr[row][col];
 printf("Enter value on the array\n");
    for(int i=0 ; i<row;i++){
        for(int j=0;j<col;j++){
            scanf("%d" , &arr[i][j]);
        }
    }
  // swap column

  for(int i=0;i<row;i++){
    int temp= 0;
    int start = 0;
    int end = col-1;
    while(start<end){
        temp = arr[i][start];
        arr[i][start] = arr[i][end];
        arr[i][end] = temp;

        start++;
        end--;
    }

  }




    printf("Array value after swap\n");
    for(int i=0 ; i<row;i++){
        for(int j=0;j<col;j++){
           printf("%d ",arr[i][j]);
        }
        printf("\n");
    }
 




   


   


}