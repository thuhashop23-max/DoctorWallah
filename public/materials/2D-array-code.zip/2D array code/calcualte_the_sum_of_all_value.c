#include<stdio.h>

int main(){
    
    int row , col;
    int sum = 0;
    printf("Enter the value of row: ");
    scanf("%d",&row);
    printf("Enter the value of column: ");
    scanf("%d",&col);

    int arr[row][col];
 printf("Enter value on the array\n");
    for(int i=0 ; i<row;i++){
        for(int j=0;j<col;j++){
            scanf("%d" , &arr[i][j]);
        }
    }

    printf("Array value\n");
    for(int i=0 ; i<row;i++){
        for(int j=0;j<col;j++){
           printf("%d ",arr[i][j]);
        }
        printf("\n");
    }
 // Calculate sum
    for(int i=0 ; i<row;i++){
        for(int j=0;j<col;j++){
           sum += arr[i][j];
        }
    }

    //Printf sum
    printf("Sum of all the values of the array: %d" , sum);




   


   


}