#include<stdio.h>

int main(){
    
    int m , n;
    printf("Enter the value of row: ");
    scanf("%d",&m);
    printf("Enter the value of column: ");
    scanf("%d",&n);

    int A[m][n];
    int B[m][n];
    int C[m][n];
 printf("Enter value on the array A\n");
    for(int i=0 ; i<m;i++){
        for(int j=0;j<n;j++){
            scanf("%d" , &A[i][j]);
        }
    }

    printf("Enter value on the array B\n");
    for(int i=0 ; i<m;i++){
        for(int j=0;j<n;j++){
            scanf("%d" , &B[i][j]);
        }
    }

    for(int i=0 ; i<m;i++){
        for(int j=0;j<n;j++){
          C[i][j] = A[i][j] + B[i][j];
        }
    }





    printf("Array value of C\n");
    for(int i=0 ; i<m;i++){
        for(int j=0;j<n;j++){
           printf("%d ",C[i][j]);
        }
        printf("\n");
    }
 




   


   


}