#include<iostream>
#include<utility>

using namespace std;
int binarySearch(int arr[], int n, int k);
void bubbleSort(int arr[], int n);


int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];
    for(int i=0; i<n; i++){
        cin >> A[i];
    }

    bubbleSort(A, n);

    int key;
    cout << "Key = ";
    cin >> key;

   int index1 = binarySearch(A, n, key);

   cout << "Target should be inserted at index = " << index1;

}

int binarySearch(int arr[], int n, int k){
    int l = 0;
    int r = n-1;
    int mid;

    while(l<=r){
        mid = (l+r)/2;
        
        if(arr[mid]==k){
            return mid;
        } else if(arr[mid] > k){ 
            r = mid - 1;
        } else {
            l = mid + 1;
        }
    }
    return l;
}

void bubbleSort(int arr[], int n){
    for(int i=0; i<n-1; i++){
            int swapped = 0;
        for(int j=0; j<n-1-i; j++){
            if(arr[j] > arr[j+1]){
                swap(arr[j], arr[j+1]);

                swapped = 1;
            }
        }
        if(swapped==0){
            break;
        }
    }

}