#include<iostream>
#include<utility>

using namespace std;

void bubbleSort(int arr[], int n);
int lastOccurance(int arr[], int n, int k);
int firstOccurance(int arr[], int n, int k);

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];
    for(int i=0; i<n; i++){
        cin >> A[i];
    }

    bubbleSort(A, n);

    int key;
    cout << "Key = ";
    cin >> key;


   int first = firstOccurance(A, n, key); 
   int last = lastOccurance(A, n, key); 

    if(first == -1 && last == -1){
        cout << "Key Not Found";
    } else {
        cout << "Total Occurance = " << last - first + 1;
    }

}

int firstOccurance(int arr[], int n, int k){
    int l = 0;
    int r = n-1;
    int mid;
    int ans = -1;
    

    while(l<=r){
        mid = (l+r)/2;
        
        if(arr[mid]==k){
            ans = mid;
            r = mid-1;
        } else if(arr[mid] > k){
            r = mid - 1;
        } else {
            l = mid + 1;
        }
    }
    return ans;

    
}

int lastOccurance(int arr[], int n, int k){
    int l = 0;
    int r = n-1;
    int mid;  
    int ans = -1;

    

    while(l<=r){
        mid = (l+r)/2;
        
        if(arr[mid]==k){
            ans = mid;
            l = mid + 1;;
        } else if(arr[mid] > k){
            r = mid - 1;
        } else {
            l = mid + 1;
        }
    }
    return ans;

    
}

void bubbleSort(int arr[], int n){
    for(int i=0; i<n-1; i++){
            int swapped = 0;
        for(int j=0; j<n-1-i; j++){
            if(arr[j] > arr[j+1]){
                swap(arr[j], arr[j+1]);

                swapped = 1;
            }
        }
        if(swapped==0){
            break;
        }
    }

}