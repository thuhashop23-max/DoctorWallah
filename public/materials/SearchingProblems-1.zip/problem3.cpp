#include<iostream>
using namespace std;

int findBiggerThanTarget(int arr[], int n, int target);

int main(){
    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];
    for(int i=0; i<n; i++){
        cin >> A[i];
    }

    int target;
    cout << "Target value = ";
    cin >> target; 

    int found = findBiggerThanTarget(A, n, target);

    if(found == 0){
        cout << "No Such Value Exists";
    } else {
        cout << found << " is greater than given target";
    }

}

int findBiggerThanTarget(int arr[], int n, int target){

    for(int i=0; i<n; i++){
        if(arr[i] > target){
            return arr[i];
        }
        if(i==n){
            return -1;
        }
    }

}