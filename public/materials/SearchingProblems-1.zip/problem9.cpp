#include<iostream>
#include<utility>

using namespace std;
int closestElement(int arr[], int n, int k);
void bubbleSort(int arr[], int n);

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];
    for(int i=0; i<n; i++){
        cin >> A[i];
    }

    bubbleSort(A, n);

    int key;
    cout << "Key = ";
    cin >> key;


   //Binary Search Loop

   int index1 = closestElement(A, n, key);
    if(index1 == -1){
        cout << "Target is already in the array";
    } else {
        cout << "Closest element: " << index1;
    }

}

int closestElement(int arr[], int n, int k){
    int l = 0;
    int r = n-1;
    int mid;

    while(l<=r){
        mid = (l+r)/2;
        
        if(arr[mid]==k){
            return -1;
        } else if(arr[mid] > k){
            r = mid - 1;
        } else {
            l = mid + 1;
        }
    }
    if(l>r){
        if(arr[mid] - k < k - arr[mid-1]){
            return arr[mid];
        } else if (arr[mid] - k == k - arr[mid-1]){
            return arr[mid-1];
        } else{
            return arr[mid-1];
        }
    }
}


void bubbleSort(int arr[], int n){
    for(int i=0; i<n-1; i++){
            int swapped = 0;
        for(int j=0; j<n-1-i; j++){
            if(arr[j] > arr[j+1]){
                swap(arr[j], arr[j+1]);

                swapped = 1;
            }
        }
        if(swapped==0){
            break;
        }
    }

}