#include<iostream>

using namespace std;
int findPeak(int arr[], int n);

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];
    for(int i=0; i<n; i++){
        cin >> A[i];
    }

   int index1 = findPeak(A, n);
    cout << "Peak Element index = " << index1;

}

int findPeak(int arr[], int n){
    int l = 0;
    int r = n-1;
    int mid;

    while(l!=r){
        mid = (l+r)/2;
        
        if(arr[mid] < arr[mid+1]){
            l = mid+1;
        } else {
            r = mid;
        }
    }
    return l;
}

      

