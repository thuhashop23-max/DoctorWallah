#include<iostream>
using namespace std;

int* indicesArray(int arr[], int n, int target, int &resultArraySize);

int main(){
    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];
    for(int i=0; i<n; i++){
        cin >> A[i];
    }

    int target;
    cout << "Target value = ";
    cin >> target;

    int resultArraySize = 0;
    int* result = indicesArray(A, n, target, resultArraySize);

    if(resultArraySize == 0){
        cout << "Target Not Found";
    } else{
        cout << "[ ";
        for(int i = 0; i<resultArraySize; i++){
            cout << result[i] << " ";
        }
        cout << "]";

    }
}

int* indicesArray(int arr[], int n, int target, int &resultArraySize){

    // how many times the number occurs
    int count = 0;
    for(int i=0; i<n; i++){
        if(arr[i] == target){
            count++;
        }
    }

    if(count == 0){
        resultArraySize = 0;
        return nullptr;
    }

    // index of occurance
    int* result = new int[count];
    int index = 0;
     for(int i=0; i<n; i++){
        if(arr[i] == target){
            result[index] = i;
            index++;
        }
     }

     resultArraySize = count;
     return result;


}