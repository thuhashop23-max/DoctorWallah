#include<stdio.h>

int main(){
   
    

   int gcd = 0;
   float lcm = 0.0;

   int a , b;
   printf("Enter 2 number:");
   scanf("%d%d",&a, &b);

   int n;

   if(a>b){
     n=b;
   }
   else{
    n=a;
   }

   for(int i=1 ; i<n ; i++){
    if(a % i == 0 && b % i == 0)
    {
        gcd = i;
    }
   }


   lcm = (a*b) / (float)gcd;

   printf("GCD=%d \nLCM=%0.3f",gcd , lcm);



    return 0;
}