#include<stdio.h>

int main(){

    int n , sum=0;
    printf("Enter the value of n:");
    scanf("%d",&n);

    int num = 0;

    for(int i=1 ; i<=n ; i++)
    {

        num = num * 10 + 9;
        printf("%d ", num);
        sum += num;

    }

    printf("\nSum of the series is %d",sum);




   


    return 0;
}