#include<stdio.h>

int main(){
   
    int x;
    printf("Enter the value of x:");
    scanf("%d" , &x);
    int a = 1;

    int facto = 1;
    int muliti = 1;

    float sum = 0.0;

    for(int i=1 ; i<=x ; i++)
    {
          facto = 1;
          muliti = 1;

          //Calcuate factorial

          for(int j=1 ; j<=a ; j++)
          {

            facto *= j;

          }
          
          //cube x^3
          for(int k=1 ; k<=a ; k++)
          {

           muliti *= x;

          }

          if(i % 2 != 0){
            sum = sum + (muliti/(float)facto);
          }
          else{

             sum = sum - (muliti/(float)facto);

          }

          a+=2;
    }


    printf("Sin(%d) is = %0.3f" ,x , sum);
    




    return 0;
}