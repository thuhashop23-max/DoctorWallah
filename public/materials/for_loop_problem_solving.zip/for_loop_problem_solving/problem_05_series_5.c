#include<stdio.h>

int main(){
    int X , Y;

    printf("Enter the value of X and Y:");
    scanf("%d%d",&X , &Y);


    while(X < Y)
    {
        printf("%d,",X*X);
        X++;
    }

      while(X > Y)
    {
        printf("%d,",X*X);
        X--;
    }

    if(X == Y)
    {
        printf("Reached!");
    }



    return 0;
}