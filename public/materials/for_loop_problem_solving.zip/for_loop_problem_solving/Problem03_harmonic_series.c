#include<stdio.h>

int main(){

    int n , a = 1;

    float sum = 0.0;
    printf("Enter the value of n:");
    scanf("%d",&n);


    for(int i=1 ; i<=n ; i++){
        if(i == n)
        {
            printf("%d/%d",a , i);
        }
        else
        {
              printf("%d/%d + ",a , i);
        }

        sum += a / (float)i ;
    }

    printf("\nSum of the series upto %d terms = %0.4f",n , sum);

   


    return 0;
}