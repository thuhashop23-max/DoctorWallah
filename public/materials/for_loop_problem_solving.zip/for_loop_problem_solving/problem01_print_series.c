#include<stdio.h>

int main(){

    int n;
    printf("Enter the value of n:");
    scanf("%d",&n);

    int a = 1;


    for(int i=1 ; i<=n ; i++){
        if(a == n)
        {
            printf("%d",a);
            a++;
        }
        else{
            printf("%d,",a);
            a++;
        }
       
    }


    return 0;
}