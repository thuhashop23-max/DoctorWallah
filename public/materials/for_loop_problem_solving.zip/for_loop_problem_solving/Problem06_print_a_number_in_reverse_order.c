#include<stdio.h>

int main(){
   
    int num , rev=0 , digit = 0;

    printf("Enter the value of num:");
    scanf("%d",&num);

    int actual_Num = num;

    while(num != 0){
        digit = num % 10;
        rev = rev * 10 + digit;
        num = num / 10;
    }

    printf("The actual number:%d\n",actual_Num);
    printf("The number in reverse order:%d",rev);




    return 0;
}