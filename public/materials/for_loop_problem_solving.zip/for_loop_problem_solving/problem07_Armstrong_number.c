#include<stdio.h>

int main(){
   
    int num , mutip=1 , sum=0 , actual_number;
    int count=0;

    printf("Enter the number:");
    scanf("%d",&num);

    actual_number = num;

    //digit count
    while(num != 0)
    {
        num = num / 10;
        count++;
    }

    int num2 = actual_number;


    while(num2 != 0)
    {
        int digit = num2 % 10;
        mutip = 1;

        for(int i=1 ; i<=count ; i++)
        {
            mutip *= digit;
        }
        sum = sum + mutip;
        num2 = num2 / 10;
    }

    if(actual_number == sum){
        printf("Armstrong number");
    }
    else{
        printf("Not Armstrong number");
    }





    return 0;
}