#include<stdio.h>

int main(){
   
    

    int n , sum=0;
    printf("Enter the number of n:");
    scanf("%d",&n);

    for(int i=1 ; i<=n ; i++){
        if(i % 2 != 0)
        {
            if(i == 1){
              printf("%d",i);
            }
            else{
               printf("+%d",i);
            }
           
            sum += i;
        }

        else{

            printf("-%d",i);
            sum -= i;

        }
    }


    printf("\nSum of the series is %d",sum);




    return 0;
}