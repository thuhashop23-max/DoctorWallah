#include<stdio.h>

int main(){
   
     int start , end , sum = 0;

     printf("Enter the Start & End number:");
     scanf("%d%d",&start , &end);


     printf("Perfect Number:");
     for(int i=start ; i<=end ; i++)
     {
        sum = 0;

        for(int j=1 ; j<=i/2 ; j++)
        {
            if(i % j == 0){
                sum += j;
            }
        }

        if(sum == i)
        {
            printf("%d ",i);
        }
     }

    


    

    

   



    return 0;
}