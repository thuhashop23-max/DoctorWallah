#include<stdio.h>


int main()
{

    int arr1[5];

    arr1[0] = 2;
    arr1[1] = 4;
    arr1[2] = 8;
    arr1[3] = 7;
    arr1[4] = 5;

    int sum = 0;

    for (int i = 0; i < 5; i++)
    {
        sum = sum + arr1[i];
    }

    float avg = (float)sum / 5;

    printf("%d\n", sum);
    printf("%f", avg);

    return 0;
}