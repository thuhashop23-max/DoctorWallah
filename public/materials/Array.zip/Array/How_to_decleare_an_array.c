#include <stdio.h>

int main()
{

    // int arr[]={2,4,6,7,8,50,78};  // inline assignment

    // //sizeof()-> total byte

    // // int bytes = sizeof(arr);
    // // printf("%d\n", bytes);

    // int size = sizeof(arr) / sizeof(int); 
    // printf("Size of the array is: %d", size);

     int arr1[5];

    arr1[0] = 2;
    arr1[1] = 4;
    arr1[2] = 8;
    arr1[3] = 7;
    arr1[4] = 5;

    for (int i = 0; i <= 4;i++)
    {
        arr1[i] = arr1[i] * 2;
        printf("%d ", arr1[i]);
    }

        return 0;
}