#include<stdio.h>


int main()
{

    int matrix[4][2] = {{8, 6}, {5, 6}, {4, 3}, {7, 9}};

    printf("%d", matrix[0][0]);

    return 0;
}