#include<stdio.h>

int main()
{

    int size;
    printf("Enter the student number:");
    scanf("%d", &size);

    // mark input

    int std_mark[size];

    for (int i = 0; i < size; i++)
    {
        printf("std_mark[%d] = ", i);
        scanf("%d", &std_mark[i]);
    }

    for (int i = 0; i < size; i++)
    {
        printf("%d ", std_mark[i]);
    }

        return 0;
}