#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);   

    int mid = n / 2;   

    for (int i = 0; i < n; i++) {
        int off;
        if (i < mid) {
            off = i;               // top half
        } else {
            off = n - 1 - i;       // bottom half
        }

        for (int j = 0; j < n; j++) {
            if (i == mid) {
                printf("$");       // middle row full $
            }
            else if (j == mid - off || j == mid || j == mid + off) {
                printf("$");       // 3 positions of $
            } 
            else {
                printf("_");       // other positions
            }
        }
        printf("\n");
    }

    return 0;
}
