#include<stdio.h>

int main()
{

    int row , col;
    printf("Enter the value of row:");
    scanf("%d" , &row);

    printf("Enter the value of column:");
    scanf("%d" , &col);


    for(int i=1 ; i<=row ; i++)
    {
        for(int j=1 ; j<=col ; j++)
        {
            printf("*");
        }
        printf("\n");
    }




    return 0;
}