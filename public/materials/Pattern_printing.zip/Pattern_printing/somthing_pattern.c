#include<stdio.h>

int main()
{

  int n;
  printf("Enter the value of n:");
  scanf("%d",&n);

  int col = (n*2)-1;
  int nsp = 1;
  int nst = col/2;
 

  for(int i=1 ; i<= col ; i++)
  {
    printf("*");
  }
  printf("\n");

    for(int i=1 ; i<=col ; i++)            
    {
        //star
        for(int j=1 ; j<=nst ; j++)
        {
            printf("*");
        }
        
        //space
        for(int k=1 ; k<=nsp ; k++)
        {
            printf(" ");
        }

        //star
         for(int j=1 ; j<=nst ; j++)
        {
            printf("*");
        }


        nst--;
        nsp+=2;

      
    printf("\n");
       

    }    




    return 0;
}