#include<stdio.h>

int main()
{

  int n;
  printf("Enter the value of n:");
  scanf("%d",&n);

 


    for(int i=1 ; i<=n ; i++)            
    {
        int a = i-1;

        // space
        for(int j = 1 ; j<=n-i ; j++)
        {
            printf(" ");
        }

        // star
        for(int j = 1 ; j<=i; j++)
        {
            printf("%d",j);
           
        }

         for(int k = 1 ; k<=i; k++)
        {

            if(a == 0)
            {
                continue;
            }
            else{
                 printf("%d",a);
                  a--;

            }
           
           
        }



    printf("\n");
       

    }    




    return 0;
}