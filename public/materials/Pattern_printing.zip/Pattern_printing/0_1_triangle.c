#include<stdio.h>

int main()
{

  int n;
  printf("Enter the value of n:");
  scanf("%d",&n);

  int m = 0;


    // for(int i=1 ; i<=n ; i++)            
    // {

    //     if(i % 2 != 0)
    //     {
    //         m = 1;
    //     }
    //     else{
    //         m = 0;
    //     }
       
    //     for(int j=1 ; j<=i; j++)
    //     {
    //         printf("%d" , m);

    //         if(m == 0)
    //         {
    //             m = 1;
    //         }
    //         else{
    //             m = 0;
    //         }
    //     }
    //     printf("\n");
    // }

    
    for(int i=1 ; i<=n ; i++)            
    {
  
        for(int j=1 ; j<=i; j++)
        {

            if( i == j || (i+j) % 2 == 0)
            {
                printf("1 ");
            }
            else
            {
                printf("0 ");
            }
           
        }
        printf("\n");
    }




   



    return 0;
}