#include<stdio.h>

int main()
{

  int n;
  printf("Enter the value of n:");
  scanf("%d",&n);

  int col = (n*2)-1;
  int nsp = 1;
  int nst = col/2;
 

  for(int i=1 ; i<= col ; i++)
  {
    printf("%d",i);
  }
  printf("\n");

    for(int i=1 ; i<=col ; i++)            
    {
        int a = 1;
        //star
        for(int j=1 ; j<=nst ; j++)
        {
            printf("%d",a);
            a++;
        }
        
        //space
        for(int k=1 ; k<=nsp ; k++)
        {
            printf(" ");
            a++;
        }

        //star
         for(int j=1 ; j<=nst ; j++)
        {
            printf("%d",a);
            a++;
        }


        nst--;
        nsp+=2;

      
    printf("\n");
       

    }    




    return 0;
}