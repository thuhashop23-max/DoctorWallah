#include<iostream>
#include<utility>
#include<cmath>             

using namespace std;
void bubbleSort(int arr[], int n);

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];

    for(int i=0; i<n ; i++){
        cin >> A[i];
    }

    bubbleSort(A, n);

    for(int i=0; i<n ; i++){
        cout << A[i] << " ";
    }
}

void bubbleSort(int arr[], int n){
    int temp;

    for(int i=0; i<n-1; i++){
            int swapped = 0;
        for(int j=0; j<n-1-i; j++){
            if(abs(arr[j]) > abs(arr[j+1])){
                swap(arr[j], arr[j+1]);

                swapped = 1;
            }
        }
        if(swapped==0){
            break;
        }
    }
}
