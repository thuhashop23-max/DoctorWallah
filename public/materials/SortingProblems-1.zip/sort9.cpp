#include<iostream>
#include<utility>

using namespace std;
void bubbleSort(int arr[], int n);

int main(){

    int n1;
    cout << "Array Size of A: ";
    cin >> n1;

    int A[n1];
    for(int i=0; i<n1 ; i++){
        cin >> A[i];
    }

    int n2;
    cout << "Array Size of B: ";
    cin >> n2;

    int B[n2];
    for(int i=0; i<n2 ; i++){
        cin >> B[i];
    }

    int n3 = n1+n2;
    int C[n3];

    for(int i = 0; i<n3; i++){
        C[i] = A[i];
    }

    for(int i = 0; i<n3; i++){
        C[n1] = B[i];
        n1++;
    }
   
    bubbleSort(C, n3);

    for(int i = 0; i<n3; i++){
        cout << C[i] << " ";
    }


}

void bubbleSort(int arr[], int n){
    int temp;

    for(int i=0; i<n-1; i++){
            int swapped = 0;
        for(int j=0; j<n-1-i; j++){
            if(arr[j] > arr[j+1]){
                swap(arr[j], arr[j+1]);

                swapped = 1;
            }
        }
        if(swapped==0){
            break;
        }
    }
}
