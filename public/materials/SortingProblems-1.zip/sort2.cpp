#include<iostream>
#include<utility>

using namespace std;
void bubbleSort(int arr[], int n);

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];

    for(int i=0; i<n ; i++){
        cin >> A[i];
    }

    bubbleSort(A, n);

    int mid_index, mid;
    if(n%2 != 0){         
        mid_index = n/2;
        mid = A[mid_index];
        cout << "Median = " << mid ;
    } else{
        mid_index = n/2;
        mid = (A[mid_index-1] + A[mid_index])/2;  
        cout << "Median = " << mid ;
    }

    
}

void bubbleSort(int arr[], int n){
    int temp;

    for(int i=0; i<n-1; i++){
            int swapped = 0;
        for(int j=0; j<n-1-i; j++){
            if(arr[j] > arr[j+1]){
                swap(arr[j], arr[j+1]);

                swapped = 1;
            }
        }
        if(swapped==0){
            break;
        }
    }
}
