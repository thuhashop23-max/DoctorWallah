#include<iostream>
#include<utility>

using namespace std;

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];

    for(int i=0; i<n ; i++){
        cin >> A[i];
    }

    // even index in ascending order
    for(int i = 0; i<n; i+=2){
        for(int j = i+2; j<n; j+=2){
            if(A[i] > A[j]){
                swap(A[i], A[j]);
            }
        }
    }

    // odd index in descending order
    for(int i = 1; i<n; i+=2){
        for(int j = i+2; j<n; j+=2){
            if(A[i] < A[j]){
                swap(A[i], A[j]);
            }
        }
    }

    for(int i=0; i<n ; i++){
        cout << A[i] << " ";
    }


}