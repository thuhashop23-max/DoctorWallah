#include<iostream>
#include<utility>

using namespace std;
void bubbleSort(int arr[], int n);

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];

    for(int i=0; i<n ; i++){
        cin >> A[i];
    }

    bubbleSort(A, n);

    int diff;
    int min_diff = A[1] - A[0];
    for( int i=0; i<n; i++){
        diff = A[i+1] - A[i]; 
        if(diff < min_diff){
            min_diff = diff;
        }
    }
    cout << "Minimum Difference: " << min_diff;
}

void bubbleSort(int arr[], int n){
    int temp;

    for(int i=0; i<n-1; i++){
            int swapped = 0;
        for(int j=0; j<n-1-i; j++){
            if(arr[j] > arr[j+1]){
                swap(arr[j], arr[j+1]);

                swapped = 1;
            }
        }
        if(swapped==0){
            break;
        }
    }
}
