#include<iostream>
#include<utility>

using namespace std;
void bubbleSort(int arr[], int n);

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int ST[n];
    int FT[n];

    cout << "Starting Time: ";
    for(int i=0; i<n ; i++){
        cin >> ST[i];
    }

    cout << "Finishing Time: ";
    for(int i=0; i<n ; i++){
        cin >> FT[i];
    }

    
    int duration1;
    int duration2;
    for(int i=0; i<n-1; i++){
        for(int j=0; j<n-1-i; j++){
            duration1 = FT[j] - ST[j];
            duration2 = FT[j+1] - ST[j+1];

            if(duration1 > duration2){
                swap(FT[j], FT[j+1]);
                swap(ST[j], ST[j+1]);

        }
        }
    }

    for(int i=0; i<n ; i++){
    cout << "( " << ST[i] << " , " << FT[i] << " ) , ";
        
    }


}
