#include<iostream>
#include<utility>

using namespace std;
void bubbleSort(int arr[], int n);

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];

    for(int i=0; i<n ; i++){
        cin >> A[i];
    }

    bubbleSort(A, n);
    int count = 1;
    int max_count = 1;
    for(int i=0; i<n; i++){
        if(A[i]+1 == A[i+1]){
            count++;
        } else {
            count = 1;
        }

        if(count > max_count){
            max_count = count;
        }
    }

    cout << "Max Count = " << max_count;

}

void bubbleSort(int arr[], int n){
    int temp;

    for(int i=0; i<n-1; i++){
            int swapped = 0;
        for(int j=0; j<n-1-i; j++){
            if(arr[j] > arr[j+1]){
                swap(arr[j], arr[j+1]);

                swapped = 1;
            }
        }
        if(swapped==0){
            break;
        }
    }
}
