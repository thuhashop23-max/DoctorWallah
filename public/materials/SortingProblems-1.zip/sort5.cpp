#include<iostream>
#include<utility>

using namespace std;
void bubbleSortString(string arr[], int n);

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;
    cin.ignore();

    string A[n];

    for(int i=0; i<n ; i++){
        getline(cin, A[i]);
    }

    bubbleSortString(A, n);

    for(int i=0; i<n ; i++){
        cout << A[i] << " ";
    }


}

void bubbleSortString(string arr[], int n){
    int temp;

    for(int i=0; i<n-1; i++){
            int swapped = 0;
        for(int j=0; j<n-1-i; j++){
            if(arr[j].length() > arr[j+1].length()){
                swap(arr[j], arr[j+1]);

                swapped = 1;
            }
        }
        if(swapped==0){
            break;
        }
    }
}
