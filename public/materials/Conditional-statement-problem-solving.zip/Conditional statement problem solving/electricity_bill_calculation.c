#include<stdio.h>
#include<math.h>

int main(){

    int id;
    char name;
    int unit;
    float charge;
    float surcharge;

    printf("Enter your id:");
    scanf("%d",&id);
    printf("Enter your name:");
    scanf(" %c",&name);
    printf("Enter the unit number:");
    scanf("%d" , &unit);


    if(unit <= 199)
    {
        charge = 1.20;
    }
    else if(unit >=200 && unit < 400)
    {
        charge  = 1.50;
    }
    else if(unit >=400 && unit < 600)
    {
        charge = 1.80;
    }
    else{
        charge = 2.00;
    }

    float total_charge = charge * unit;

    if(unit > 400)
    {
        surcharge = unit * 0.15;
    }

    float total = total_charge + surcharge;



    printf("Customer IDNO: %d\n" , id);
    printf("Customer name: %c\n" , name);
    printf("Unit Consumed: %d\n" , unit);
    printf("Amount charges @Rs.%0.2f per unit:%0.2f\n" ,charge , total_charge);
    printf("Surcharge amount:%0.2f\n",surcharge);
    printf("Total amount:%0.2f\n",total);

    











   
   


    return 0;
}