#include<stdio.h>
#include<math.h>

int main(){

   float a , b ,c , x1 , x2;

   printf("Enter the value of a:");
   scanf("%f" , &a);

   
   printf("Enter the value of b:");
   scanf("%f" , &b);

   
   printf("Enter the value of c:");
   scanf("%f" , &c);


   float e = b*b - 4*a*c;

   if(e == 0)
   {
    x1 = x2 = -b / 2 * a;
    printf("First root x1 = %0.3f and Second root x2 = %0.3f" , x1 , x2);
   }

   else if(e>0)
   {
    x1 = (-b+sqrt(c)) / (2*a);
    x2 = (-b-sqrt(c)) / (2*a);
    printf("First root x1 = %0.3f and Second root x2 = %0.3f" , x1 , x2);
   }

   else{
    printf("Please check the input\n");
   }


 
   


    return 0;
}