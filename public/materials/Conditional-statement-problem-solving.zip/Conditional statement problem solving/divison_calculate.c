#include<stdio.h>
#include<math.h>

int main(){

   int roll;
   char name;
   float phy , che , ca;

   printf("Enter your roll number:");
   scanf("%d" , &roll);

   printf("Enter your name(first character):");
   scanf(" %c",&name);

   printf("Enter your marks of three subject physics , Chemistry and computer aplication:");
   scanf("%f%f%f" , &phy , &che , &ca);


   float total = phy + che + ca;

   float avg = (total / 3);

   printf("Roll no: %d\n" , roll);
   printf("Name of the student: %c\n" , name);
   printf("Marks in Physics: %0.3f\n" , phy);
   printf("Marks in Chemistry: %0.3f\n" , che);
   printf("Marks in Computer Application: %0.3f\n" , ca);
   printf("Total marks: %0.3f\n" , total);
   printf("avg: %0.3f\n" ,avg);

   if(avg >= 80 && avg <=100)
   {
    printf("Divison = First");
   }
   else if(avg >= 60 && avg<=79)
   {
    printf("Divison = Second");
   }
   





   
   


    return 0;
}