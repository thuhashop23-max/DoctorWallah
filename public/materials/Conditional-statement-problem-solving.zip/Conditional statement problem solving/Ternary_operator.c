#include<stdio.h>

int main(){

    int num;
    printf("Enter the number:");
    scanf("%d" , &num);


    (num > 0) ? printf("positive") : printf("nagetive");



    return 0;
}