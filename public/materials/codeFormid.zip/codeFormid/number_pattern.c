#include<stdio.h>

int main(){


    int n;
    scanf ("%d" , &n);

    int a;


    for(int i=1;i<=n;i++){
        a = i * 2;
        for(int j=1; j<=n-i; j++){
            printf(" ");
        }

        for(int k=1;k<=i;k++){
            printf("%d",a);

            a+=2;
            
        }
        a -= 4;

        for(int h=1; h<i ;h++){
            printf("%d" , a);
            a-=2;

        }

        printf("\n");
    }


    return 0;
}