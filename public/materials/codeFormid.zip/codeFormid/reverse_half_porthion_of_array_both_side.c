#include<stdio.h>

int main(){


    int n;
    printf("Enter the value of n(Odd):");
    scanf("%d" , &n);

    if(n % 2 == 0){
        printf("Enter a odd number.and try again");
        return 1;
    }

    int arr[n];
    printf("Input value into array:\n");
    for(int i=0;i<n;i++){
        scanf("%d" , &arr[i]);
    }

    int mid = n/2;  //(n/2 +1)-1;

    int start=0 , end = mid-1;
    int start1=mid+1 , end1 = n-1;


    //1st half reverse

    while(start<end){
        int temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;
        start++;
        end--;
    }

    // 2nd half reverse

    while(start1<end1){
        int temp = arr[start1];
        arr[start1] = arr[end1];
        arr[end1] = temp;
        start1++;
        end1--;
    }


    printf("New array \n");
    for(int i=0;i<n;i++){
        printf("%d " , arr[i]);
    }







    return 0;

}