#include<stdio.h>
#include<limits.h>

int main(){


    int n;
    printf("Enter the value of n(N must be less then 10):");
    scanf("%d" , &n);

    if(n>=10){

        printf("Enter a valid number.");
        return 1;

    }

    
    int arr[n];
    printf("Input value into array:\n");
    for(int i=0;i<n;i++){
        scanf("%d" , &arr[i]);
    }

    int max=INT_MIN , index = INT_MIN ;

    for(int i=0;i<n;i++){
        if(arr[i] % 2 == 0){
            if(max<arr[i]){
                max = arr[i];
                index = i;
            }
        }
    }

   

   printf("Maximum even number of the array is: %d  and index number = %d" , max ,index); 






    return 0;

}