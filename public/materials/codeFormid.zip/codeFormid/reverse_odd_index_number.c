#include<stdio.h>

int main(){


    int n;
    printf("Enter the value of n:");
    scanf("%d" , &n);

    int arr[n];
    printf("Input value into array:\n");
    for(int i=0;i<n;i++){
        scanf("%d" , &arr[i]);
    }

       int start = 0;
       int end;

       if(n % 2 == 0){
        end = n-2;
       }
       else{
        end = n-1;
       }
   
   
       while(start<end){
        int temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;

        start +=2;
        end -=2;
       }


    printf("Array after reverse:\n");
    for(int i=0;i<n;i++){
        printf("%d " , arr[i]);
    }

    return 0;
}