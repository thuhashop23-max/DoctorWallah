#include<stdio.h>

int main(){

    float n;
    float sum = 0;
    float count = 0;

    while(n != 0){
        printf("enter number:");
        scanf("%f" , &n);

        if(n>0){

            sum += n;
            count++;

        }
    }

    float avg = sum /count;

    printf("Online avg = %0.3f" , avg);

    return 0;


}