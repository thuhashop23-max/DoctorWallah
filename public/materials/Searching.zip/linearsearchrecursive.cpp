#include<iostream>

using namespace std;
int linearSearch(int arr[], int n, int k, int index);

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];
    for(int i=0; i<n; i++){
        cin >> A[i];
    }

    int key;
    cout << "Key = ";
    cin >> key;

    // Linear search (Recursive)
    int index = linearSearch(A, n, key, 0);
    if(index == -1){
        cout << "Key Not Found";
    } else {
        cout << "Key Found at index " << index;
    }

}

int linearSearch(int arr[], int n, int k, int index){

    // base case
    if(index == n){
        return -1;
    }

    // check current element
    if(arr[index] == k){
        return index;
    }

    // recursive call
    return linearSearch(arr, n, k, index + 1);
    
}