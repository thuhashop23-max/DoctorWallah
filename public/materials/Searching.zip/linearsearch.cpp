#include<iostream>

using namespace std;
int linearSearch(int arr[], int n, int k);

int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];
    for(int i=0; i<n; i++){
        cin >> A[i];
    }

    int key;
    cout << "Key = ";
    cin >> key;

    //Linear search
    int index = linearSearch(A, n, key);
    if(index == -1){
        cout << "Key Not Found";
    } else {
        cout << "Key Found at index " << index;
    }

}

int linearSearch(int arr[], int n, int k){

    for (int i=0; i<n; i++){

        if(arr[i] == k){
            return i;
        }
    }
    return -1;
    
}
