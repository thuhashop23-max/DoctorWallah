#include<iostream>
#include<utility>

using namespace std;
int binarySearch(int arr[], int n, int k);
void bubbleSort(int arr[], int n);
int binarySearchRecurisve(int arr[], int l, int r, int k);


int main(){

    int n;
    cout << "Array Size: ";
    cin >> n;

    int A[n];
    for(int i=0; i<n; i++){
        cin >> A[i];
    }

    bubbleSort(A, n);

    int key;
    cout << "Key = ";
    cin >> key;


   //Binary Search Loop

   int index1 = binarySearch(A, n, key);
    if(index1 == -1){
        cout << "Key Not Found";
    } else {
        cout << "Key Found at index " << index1;
    }

    //Binary Search Recursive
    int l = 0;
    int r = n-1;

    int index = binarySearchRecurisve(A, l, r, key);
        if(index == -1){
        cout << "Key Not Found";
        } else {
        cout << "Key Found at index " << index;
        }

}

int binarySearch(int arr[], int n, int k){
    int l = 0;
    int r = n-1;
    int mid;

    while(l<=r){
        mid = (l+r)/2;
        
        if(arr[mid]==k){
            return mid;
        } else if(arr[mid] > k){
            r = mid - 1;
        } else {
            l = mid + 1;
        }
    }
    if(l>r){
        return -1;
    }
}

int binarySearchRecurisve(int arr[], int l, int r, int k){
        if(l>r){
            return -1;
        }

        int mid = (l+r)/2;

        if(arr[mid]==k){
            return mid;
        } else if(arr[mid] > k){
            return binarySearchRecurisve(arr, l, mid-1, k);
        } else {
            return binarySearchRecurisve(arr, mid+1, r, k);
        }
      

}

void bubbleSort(int arr[], int n){
    for(int i=0; i<n-1; i++){
            int swapped = 0;
        for(int j=0; j<n-1-i; j++){
            if(arr[j] > arr[j+1]){
                swap(arr[j], arr[j+1]);

                swapped = 1;
            }
        }
        if(swapped==0){
            break;
        }
    }

}